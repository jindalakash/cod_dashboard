This is a Cause of Death Dashboard App. 

The dashboard has been designed on Grafana and has been integrate with DHIS2 data.
